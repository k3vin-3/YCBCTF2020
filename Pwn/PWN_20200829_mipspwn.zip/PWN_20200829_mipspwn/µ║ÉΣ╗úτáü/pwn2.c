
#include <stdio.h>
#include <stdlib.h>
char name[24];
int *size[10];
int number = 0;
char *chunk[10];
int main(int argc, const char **argv, const char **envp)
{
  int v3;
  init();
  puts("Warrior,leave your name here:");
  read(0,name,8);
  printf("hello,%s",name);
  while ( 1 )
  {
    while ( 1 )
    {
      menu();
      scanf("%d", &v3);
      if ( v3 != 1 )
        break;
      add();
    }
    if ( v3 == 2 )
    {
      delete();
    }
    else if ( v3 == 3 )
    {
      edit();
    }
    else if ( v3 == 7 )
    {
      description();
    }
    else
    {
      if ( v3 == 4 )
      {
        puts("See you tomorrow~");
        exit(0);
      }
      puts("Invalid choice!");
    }
  }
}
int init()
{
  setvbuf(stdin, 0LL, 2, 0LL);
  setvbuf(stdout, 0LL, 2, 0LL);
  setvbuf(stderr, 0LL, 2, 0LL);
  return memset(chunk, 0, 0x50uLL);
}
int add()
{
  int v0; 
  int v2; 
  int v3; 
  printf("Give me a block ID: ");
  scanf("%d", &v3);
  printf("how big: ", &v3);
  scanf("%d", &v2);
  if ( v3 >= 0 && v3 <= 9 && number <= 10 )
  {
    if(v2>=0&&v2<0x100)
    {
    v0 = v3;
    chunk[v0] = malloc(v2);
    size[v0] = v2;
    ++number;
    return puts("Done!\n");
    }
    else
    {
      puts("too large!");
    }
  }
}
int delete()
{
  int v1;
  unsigned int v2;
  v1 = 0;
  puts("Which one to throw?");
  scanf("%d", &v1);
  if ( v1 > 10 || v1 < 0 )
  {
    v2 = puts("Wrong!\n");
  }
  else
  {
    free(chunk[v1]);
    --number;
    v2 = puts("Done!\n");
  }
  return v2;
}

int edit()
{
  int idx;
  printf("Which block to write?");
  scanf("%d",&idx);
  printf("Content: ");
  read_0(chunk[idx], size[idx]);
  return puts("Done!\n");
}
int read_0(char *a1,int a2)
{
  int v3;
  char buf[10];
  int i = 0;
  for ( ; ; ++i )
  {
    v3 = i;
    if ( i >= a2 )
    	break;
    read(0, buf, 1);
    if ( *buf == 10 )
    	break;
    *(i + a1) = *buf;
  }
  // *(i + a1) = 0;
  return v3;
}
void vul()
{
  char buf[50];
  read(0,buf,0xb0);
}
void description()
{
  puts("Write down your feeling:");
  vul();
}
void abc()
{
  puts("123 3123 32");
  char buf[50];
  puts("just do it~");
  read(0,buf,30);
}

int menu()
{
  puts("\n***********************");
  puts("Welcome to the magic block world!");
  puts("***********************");
  puts("1.create a block");
  puts("2.throw a block");
  puts("3.write something on the block");
  puts("4.exit the world");
  return printf("Your choice: ");
}